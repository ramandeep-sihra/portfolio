import React from 'react';

function Resume({ data }) {

    if (data) {
        var skillmessage = data.skillmessage;
        var education = data.education.map(function (education) {
            return <div key={education.school}><h3>{education.school}</h3>
                <p className="info">{education.degree}<br></br><em className="date">{education.graduated}</em></p>
                <p>{education.description}</p></div>
        })
        var certifications = data.certifications.map(function (certifications) {
            return <div key={certifications.school}><h3>{certifications.school}</h3>
                <p className="info">{certifications.degree}<br></br><em className="date">{certifications.graduated}</em></p>
                <p>{certifications.description}</p></div>
        })
        var work = data.work.map(function (work) {
            return <div key={work.company}><h3>{work.company}</h3>
                <p className="info">{work.title}<span>&bull;</span> <em className="date">{work.years}</em></p>
                <p>{work.description}</p>
            </div>
        })
        var skills = data.skills.map(function (skills) {
            return <div key={skills.software}>{skills.software}{skills.data_concepts}{skills.languages} </div>
        })
    }

    return (
        <section id="resume">

            <div className="row education">
                <div className="three columns header-col">
                    <h1><span>Certifications</span></h1>
                </div>
                <div className="nine columns main-col">
                    <div className="row item">
                        <div className="twelve columns">
                            {certifications}
                        </div>
                    </div>
                </div>
            </div>

            <div className="row education">
                <div className="three columns header-col">
                    <h1><span>Education</span></h1>
                </div>
                <div className="nine columns main-col">
                    <div className="row item">
                        <div className="twelve columns">
                            {education}
                        </div>
                    </div>
                </div>
            </div>

            <div className="row work">
                <div className="three columns header-col">
                    <h1><span>Work</span></h1>
                </div>

                <div className="nine columns main-col">
                    {work}
                </div>
            </div>

            <div className="row skill">
                <div className="three columns header-col">
                    <h1><span>Skills</span></h1>
                </div>

                <div className="nine columns main-col">
                    <p>{skillmessage}
                    </p>

                    <div>
                        <ul className="skills">
                            {skills}
                        </ul>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default Resume;
