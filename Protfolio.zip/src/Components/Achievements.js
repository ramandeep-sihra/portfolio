import React from 'react';

function Achievements({data}) {

    if(data){
      var achievements = data.achievements.map(function(achievements){
        return  <p>{achievements.text}</p>
            // <img src={?}></img>
      })
    }

    return (
      <section id="achievements">
      <div className="text-container">
         <div className="row">

            <div className="header-col">
               <h1><span>Achievements</span></h1>
            </div>

            <div className="flex-container">
                  <ul className="slides">
                      {achievements}
                  </ul>
               </div>
            </div>
         </div>
   </section>
    );
}

export default Achievements;
